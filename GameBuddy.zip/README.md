GameBuddy — prototype web gaming.

Publication gratuite via GitHub Pages : Settings → Pages → Deploy from a branch → branche principale (main ou principal) → /(root) → Save.

Aucune publicité n’est activée et aucun revenu n’est garanti.
